package com.wipro.flowcontrolstatements;

public class Ex11 {
	public static void main(String[] args) {
		for(int i=24;i<56;i+=2)
		{
			System.out.println(i);
		}
	}

}
