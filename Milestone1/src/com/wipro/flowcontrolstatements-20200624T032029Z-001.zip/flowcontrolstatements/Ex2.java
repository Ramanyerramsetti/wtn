package com.wipro.flowcontrolstatements;

public class Ex2 {
	public static void main(String[] args) {
		int x= Integer.parseInt(args[0]);
		if(x%2==0)
			System.out.println("even");
		else
			System.out.println("odd");
	}

}
