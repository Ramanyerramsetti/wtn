package com.wipro.languagebasics;

public class Ex3 {
	public static void main(String[] args) {
		int x= Integer.parseInt(args[0]);
		int y= Integer.parseInt(args[1]);
		System.out.println("The sum of "+x+" and "+y+" is "+(x+y));
	}

}