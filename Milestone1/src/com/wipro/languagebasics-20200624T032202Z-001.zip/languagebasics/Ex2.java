package com.wipro.languagebasics;

public class Ex2 {
	public static void main(String[] args) {
		System.out.println("welcome "+args[0]);
	}

}
