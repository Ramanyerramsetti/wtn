package com.wipro.inheritance;

public class TestEmployee {
	public static void main(String[] args) {
		person sc=new person();
		
	}
}
