package com.wipro.inheritance;

public class Employee extends person{
	double annualsalary;
	int yearstarted;
	String natinsno;
	Employee(double annualsalary,int yearstarted,String natinsno)
	{
		this.annualsalary=annualsalary;
		this.yearstarted=yearstarted;
		this.natinsno=natinsno;
	}
	public static void main(String[] args) {
		
	}
}
