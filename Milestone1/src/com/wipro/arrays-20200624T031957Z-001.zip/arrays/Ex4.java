package com.wipro.arrays;

public class Ex4 {
	public static void main(String[] args) {
		int x=Integer.parseInt(args[0]);
        System.out.printf("%c",x);
		
	}

}
